# -*- coding: utf-8 -*-
"""
Created on Sun Apr 28 15:13:51 2019

@author: USER
"""

import os
from bs4 import BeautifulSoup as soup
#NOTE: supposedly the data produced will be used to predict or analyse, so accordingly the empty fileds are filled with NAN

#chekcs if there are embeded attributes
#takes a td as the argument
#if there is a td with class = "object-kenmerken-group-header" it's next sibling is a dd with embeded values
def check_embeded(title):
    if title.has_attr("class") and "object-kenmerken-group-header" in title.get("class"):
       return True
    return False

#loops through embeded data containers(elements) and extracts values
#is called when embeded data is noticed
#takes the reference of the list titles to change it if needed, t -> the counter of td elements, a reference of house_info and a reference of csv_header
#returns t -> the counter of considered td elements till now
def embeded(titles, t, house_info, csv_header):
    #subtitle for embeded elements
    sub = process_title(titles[t])
    value = titles[t].find_next_sibling("dd",{"class":"object-kenmerken-group-list"})
            
    for dt in value.find_all("dt"):

      if check_embeded(dt):
          t = embeded(value, t, houses, csv_header) + 1
      dt_processed =  process_title(dt)

      if dt_processed not in csv_header:
          csv_header.append(dt_processed)
      try:
          dd = process_value(dt.find_next_sibling("dd"))
          if dd == "":
                dd_processed = "NAN"
          else:
              dd_processed = sub + ":" + dd + ";"
          
      except:
          dd_processed = "NAN"

      finally:
          if dt_processed in house_info.keys():
              house_info[dt_processed] = house_info[dt_processed] + " " + dd_processed

          else:
              house_info[dt_processed] = " " + dd_processed
      t+=1
      
              
    return(t)

#coverts an element into a csv valid string ready for use as title of column
def process_title(title):
    return title.text.strip().lower().replace(",",";").replace(" ","_").replace("\t","__").replace("\n","___")

#converts an element into a csv valid string
def process_value(value):
    if type(value) == str:
        return value.replace(",",";").replace("\t"," ").replace("\n"," ")
    return value.text.replace(",",";").replace("\t"," ").replace("\n"," ")
    


#a list containing information gathered from all the adverts(houses)
houses = [] 
#the csv header with base attributes(which all pages have) which will be dinamiclly upgraded as more attributes are discovered
csv_header = ["huis_naam", "prijs", "project_info", "adres", "omschrijving","contacten","fotos", "buurt_voorzieningen"]

#the directory where the files needed to be sraped are in
directory = "."
#loop through files in folder and scrape them
for filename in os.listdir(directory):
    if filename.endswith(".txt"):
        try:
            file = open(filename, mode='r',encoding="utf8")
        except FileNotFoundError:
            print(filename + " not found.")
            continue
       
        try:
            whole = file.read()
            file.close()
        except:
            print("can't read: " + filename)
            continue

        #files given are txt, to use functions of beautifulsoup we need html 
        #convert txt to html
        html = soup(whole, "html.parser")
        
        #data of current house(advert)(html)
        house_info = {}
        
        
        #House name
        house_name = html.find("h1",{"class":"object-header__address"})
        house_name_processed = process_value(house_name)
        house_info["huis_naam"] = house_name_processed
        
        #House price
        house_price = html.find("div", {"class":"object-header__pricing"})
        house_price_processed = process_value(house_price).replace("Wat worden mijn maandlasten?","")
        house_info["prijs"] = house_price_processed
        
        #Project info
        try:
            project = html.find("div",{"class":"object-header__project-info"}).findChild("a")
            project_processed = process_value(project)
        except:
            project_processed = ""
        house_info["project_info"] = project_processed
        
        #House Address
        address = html.find("span",{"class":"object-header__address-city"})
        address_processed = process_value(address)
        house_info["adres"] = address_processed
        
        #Description by seller
        description = html.find("div",{"class":"object-description-body"})
        description_processed = process_value(description)
        house_info["omschrijving"] = description_processed
        
        #Contact 
        contact_names = html.find_all("a",{"class":"object-contact-aanbieder-link"})
        contact_numbers = html.find_all("div", {"class":"object-contact-show-phonenumber"})
        contacts = ""
        for contact_count in range(0, len(contact_names)):
            name = contact_names[contact_count]
            name_processed = process_value(name)
            
            number = contact_numbers[contact_count]
            number_processed = process_value(number).replace("Bel","").replace("Toon telefoonnummer","")
            
            contacts = contacts + name_processed + ":" + number_processed + ";"
        house_info["contacten"] = contacts
        
            
        #House images
        photo_objects = html.find_all("div",{"class":"object-media-foto"})
        photos = ""
        
        for photo_object in photo_objects:
            photo = photo_object.find("img").get("src")
            #the sequence that is being replaced is often seen and unnecessary
            photo_processed = process_value(photo).replace("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAQAIBRAA7","") + ";"
            photos = photos + photo_processed
        try:
            featured_photo = html.find("div",{"class":"object-header__image"}).find("img").get("src")
            featured_photo_processed = process_value(featured_photo) + ";"
            photos = photos + featured_photo_processed
        except:
            pass
        house_info["fotos"] = photos
          
        #Neigbourhood amenities
        neighbourhood = html.find_all("span",{"class":"object-buurt__term"})
        neighbourhood_amenities = ""
        for amenity in neighbourhood:
            amenity_processed = process_value(amenity)
            neighbourhood_amenities = neighbourhood_amenities + amenity_processed + ";"
            
        neighbourhood_amenities = neighbourhood_amenities
        house_info["buurt_voorzieningen"] = neighbourhood_amenities
        
        
        #Variable house characteristics
        #Variable attribute_title : attribute_values are placed in sibling sequential dt : dd elements
        #Characteristic titles
        titles = html.find_all("dt")
        #counter of considered titles
        t = 0
        while t < len(titles):
            #the variable attributes can be embeded so we must check and consider
            if check_embeded(titles[t]):
                t = embeded(titles,t,house_info,csv_header)
                t+=1
                continue
            #Variable attribute_title : attribute_values are placed in simbling sequential dt : dd elements
            value = titles[t].find_next_sibling("dd")  
            t_processed = process_title(titles[t]) 
            #the common attribute "energielabel"'s value has unwanted additional text, but is needed a single letter
            if "energielabel" in t_processed:
                v_processed = value.text.strip()[0]
            else:
                v_processed = process_value(value)
            #dynamic filling of csv header
            if t_processed not in csv_header:
                csv_header.append(t_processed)
            house_info[t_processed] = v_processed
            t+=1
        houses.append(house_info)

#csv result file
csv_filename = "csv_results.csv"
csv_header_new = ','.join(csv_header) + "\n"
  

csv_file = open(csv_filename, "w")
csv_file.write(csv_header_new)

#because the current house list dictionary may not have all the attrubites from the header and raise a KeyError
for house in houses:
    row = ""
    for h in csv_header:
        try:
            if house[h] == "":
                house[h] = "NAN"
            row += house[h]
        except KeyError:
            row += "NAN"
        row += ","
    row += "\n"
    csv_file.write(row)
csv_file.close()

    




